#include <iostream>
#include <cstddef>

class BinaryNode
{
	private:
		friend class BinarySearchTree;
		int key; int searchCost;
		BinaryNode *left,*right, *parent;
	public:
		BinaryNode(int el=0, int sc=0, BinaryNode *lt=NULL, BinaryNode *rt=NULL, BinaryNode *pt=NULL):key(el),searchCost(sc),left(lt),right(rt),parent(pt){}
	//functions
		BinaryNode *getLeft() {return left;}
		BinaryNode *getRight() {return right;}
		BinaryNode *getParent() {return parent;}
		bool isRoot(){return parent == NULL;}
		int Key(){return key;}
};
